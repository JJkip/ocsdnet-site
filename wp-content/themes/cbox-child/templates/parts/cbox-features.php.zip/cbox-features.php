<?php
/**
 * CBOX.org: Feature Overview
 *
 */
?>
	<div class="section-break green testimonials-break">
		<h2>CBOX is a platform for easy and powerful community websites.</h2>
	</div>

<div class="curated-plugins homepage-block row">

    <div class="column eight">
		<IMG SRC="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/curated-plugins.png">
	</div>

	<div class="column eight">

		<h2>Curated Plugins</h2>
			CBOX helps you to install BuddyPress along with a number of carefully selected and vetted BuddyPress plugins, so that you don't have to worry about which plugins are best and which are compatible with each other.
			<p>
			Besides the curated plugins there are also some recommended plugins you can easily install straight from the CBOX Dashboard. These plugins are not crucial but can be very helpful for your community. Do you already have a WordPress site and a set of favorite plugins? No worries, these will work just fine with Commons in a Box!
	</div>

</div>

<div class="collaboration-tools homepage-block row">

	<div class="column eight">

		<h2>Collaboration Tools</h2>
	Adds collaborative work spaces to your community. Part wiki, part document editing, part shared dropbox, it includes everything your community needs to easily work together on documents. 
	<p>
		Documents can even be linked to Discussion Groups and have different privacy levels. Want to work on a document together? The build in revision system and one-editor-at-a-time prevention system keeps things backed up and organised.
	</div>

	<div class="column eight">
		<IMG SRC="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/buddypress-docs.png">
	</div>

</div>

<div class="member-profiles homepage-block row">


    <div class="column eight">
		<IMG SRC="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/member-profiles.png">
	</div>

	<div class="column eight">

		<h2>Member Profiles</h2>
		
		Every single member of your community has it own public profile where they can share information about themselves. As the Commons administrator you can add the profile fields that are relevant for your community. For example you let your members fill in their Academic interests, Position and Educational background. 
	<p>

		The Member Directory allows your members to filter and search for other members based on these profile fields, and connect with each other through private messages or public mentions across your community. 

	</div>


</div>

<div class="discussion-groups homepage-block row">

	<div class="column eight">

		<h2>Discussion Groups</h2>
		Boost engagement by letting your community members join Discussion Groups that match their interests. These groups can be centered around any topic and can be set up with with discussion forums, document collaboration and so much more. 
		<p>
		Want to discuss something in private? Groups can be public, private or completely hidden. Access is granted by the Group Moderator(s) to ensure the right people can access the right groups. 
	</div>

		    <div class="column eight">
		<IMG SRC="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/discussion-groups.png">
	</div>


</div>


<div class="activity-streams homepage-block row">


	<div class="column eight">
		<IMG SRC="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/activity-stream.png">
	</div>

	<div class="column eight">

		<h2>Activity Streams</h2>

		Allow your members to easily keep track of what's going on across your community with the Activity Stream. New Blog posts, forum discussions and group activity is all collected in their personal stream, so they can get an overview of all the activity of their peers. 

		<p>

		Your members can post status updates about their work progress, share useful resources or simply use the stream to see the latest published blogpost across your network!	

	</div>


</div>

<div class="forums homepage-block row">

	<div class="column eight">

		<h2>Discussion Forums</h2>
		
		For in-depth discussions about various topics the discussion forums are the perfect solution. Let your community members create topics and see the threaded discussion unfold. Create seperate support forums to help your members get started with using your commons or add a forum to one of your Discussion Groups. 

		<p>

		Once your members start to participate in a forum topic they can easily subscribe to email notifications for new replies. Or maybe  you'd like to email them a a weekly summary of new topics. No problem! Even replying to a topic straight from their email is possible! 

	</div>

	<div class="column eight">
		<IMG SRC="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/discussion-forums.png">
	</div>

</div>

<div class="community-powered homepage-block row">

	<div class="column eight">
		<?php if ( bp_has_members( 'user_id=0&type=random&max=15&per_page=15' ) ) : ?>	
			<div id="member-grid" class="avatar-block">
					<?php while ( bp_members() ) : bp_the_member(); ?>
					<div class="item-avatar">
						<a class="user-avatar" href="<?php bp_member_permalink() ?>" title="<?php bp_member_name(); ?>"><?php bp_member_avatar('type=full&width=75&height=75') ?></a>
					</div>
					<?php endwhile; ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="column eight">

		<h2>Community Powered</h2>
		The Commons In a Box community is full of people that use CBOX to power their community. Visit the forums to receive help from our community and leave feedback and suggestions for the development team. You can also find extensive documentation, development tutorials and various tips and tricks on how to customize your CBOX community. 
		<p>
	
		Creat your profile on Commonsinabox.org and join us in making CBOX better. Are you a developer? Help us improve CBOX and start contributing code through <a href="https://github.com/cuny-academic-commons/" target="_blank">GitHUb</a>. 
	</div>

</div>

<div class="much-more homepage-block row">

	<div class="column eight">

		<h2>And so much more!</h2>

		Commons in a Box is build upon WordPress; the biggest Open Source software in the world. This mean that there are hundreds of volunteers all over the world working every day on making WordPress faster, easier and even more secure. 
	
	<p>
	
	There is a healthy eco system of freelance developers and consultants who are experienced in working on WordPress projects. By leveraging the power of WordPress and BuddyPress we're able to make CBOX the most powerful and flexible solution for building your commons!
		 </p>
	</div>

	
	<div class="column eight">
		<IMG SRC="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/discussion-forums.png">
	</div>

<a href="http://commonsinabox.org/download" class="button green">Download Commons in a Box</a>

</div>